from flask import Flask,render_template,url_for,request,redirect
from flask import json
import os
#import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import itertools
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from apyori import apriori

#import seaborn as sns

app =Flask(__name__) # flask application start..
    
## This for directing to that page
PEOPLE_FOLDER = os.path.join('static', 'images') # path till the image folder
app.config['UPLOAD_FOLDER'] = PEOPLE_FOLDER # Background image config file name path
main_page_background = os.path.join(app.config['UPLOAD_FOLDER'], 'main_page.jpg') # Background image path
## Files read from local path 
anime_data = pd.read_csv("G:/Aegis Study/Documents/Machine Learning/Project/Anime_data/anime.csv",na_values='NaN', keep_default_na=False)

#anime_data = pd.read_csv("G:/Aegis Study/Documents/Machine Learning/Project/Anime_data/anime.csv")
user_data = pd.read_csv("G:/Aegis Study/Documents/Machine Learning/Project/Anime_data/rating.csv")
## Gobal variable

# for search bar autocomplte
anime_name = anime_data['name'].unique()
anime_name = anime_name[~pd.isnull(anime_name)]

## 
user = user_data
anime = anime_data

user.replace(-1,np.NAN, inplace=True)
user.fillna(0, inplace=True)

mean_user_rating = user.groupby(['user_id']).mean().reset_index()
mean_user_rating.rename(columns={'rating':'mean_rating'}, inplace=True)
mean_user_rating.drop(['anime_id'],axis=1, inplace=True)

user_rating_df = user.merge(mean_user_rating)
user_rating_df = user_rating_df.drop(user_rating_df[user_rating_df.rating < user_rating_df.mean_rating].index)
user_rating_df.rename(columns={'rating':'user_rating'}, inplace=True)

merged_data = anime.merge(user_rating_df)
merged_data = merged_data[merged_data.user_id <= 20000]

user_anime_df = pd.pivot_table(merged_data, index=['user_id'], columns=['name'], values=['user_rating'], fill_value=0)


pca = PCA(n_components=600)
pca.fit(user_anime_df)
pca_samples = pca.transform(user_anime_df)
pca.explained_variance_ratio_.sum()
pca_df = pd.DataFrame(pca_samples)

anime_clusters = KMeans(n_clusters=4,random_state=30).fit(pca_df)
#centers = anime_clusters.cluster_centers_
cluster_preds = anime_clusters.predict(pca_df)

user_anime_df['cluster'] = cluster_preds

c0 = user_anime_df[user_anime_df['cluster']==0].drop('cluster',axis=1).mean()
c1 = user_anime_df[user_anime_df['cluster']==1].drop('cluster',axis=1).mean()
c2 = user_anime_df[user_anime_df['cluster']==2].drop('cluster',axis=1).mean()
c3 = user_anime_df[user_anime_df['cluster']==3].drop('cluster',axis=1).mean()


#############################       Raviraj         #############################


    

def recommendation_by_user_common_genre(user_id,anime_data,user_data):
    anime_data2 = anime_data
    #geting user anime id.....
    user_anime_id = user_data.loc[user_data['user_id'] == user_id,'anime_id']
    #sorted by index
    user_anime_id.sort_index(inplace=True)
    #fetching user watched anime genre
    user_watched_anime = anime_data2.loc[anime_data2['anime_id'].isin(user_anime_id),'anime_id':'rating']
    user_anime_genre = anime_data2.loc[anime_data2['anime_id'].isin(user_anime_id),'genre']
    anime_genre_len =[]
    value = len(user_anime_id) - int(len(user_anime_id)*0.8)
    user_watched_anime = user_watched_anime[len(user_watched_anime)-value:len(user_watched_anime)]
    user_anime_genre = user_anime_genre[0:len(user_anime_genre)]


# =============================================================================
# =============================================================================
    records = []
    for i in user_anime_genre:
        records.append([i])

# =============================================================================
# =============================================================================
    
# =============================================================================
# =============================================================================
    ass_rules = apriori(records,min_support=0.000045,min_confidence = 0.002,min_len=2)
  
    ass_list = list(ass_rules)
      
    apriori_list = list(ass_list[0][0])[0]
     
    apriori_list    
 #     
# =============================================================================
# =============================================================================
    
    anime_genre_1 =[]
    ## for 1st intration...
    ### Got genre in list of that user
    for i in user_anime_genre:
        lst = i.split(",")
        for i in lst:
            if i not in anime_genre_1:
                anime_genre_1.append(i)
                anime_genre_len.append(len(i))
        
    anime_genre_1 #---> in this list
    
    len(anime_genre_1)
    
    
    anime_genre_dic = {}
    for i in anime_genre_1:
        count = 0 
        for j in user_anime_genre:
            if i.strip() in j.replace(" ","").split(","):
                count = count+1
                
        anime_genre_dic[i.strip()] = count
    
    anime_genre_dic
    #  got dictionary of genre and it's appearances.....
    
    st = sorted(anime_genre_dic.items(), key=lambda anime_genre_dic: anime_genre_dic[1])
    # sorted that list base on appearance.. lowest to highest...
    
    st = st[::-1]
    
    ## reverse it..
    st = st[0:10]
    # top 10 ...
    
    st_genre = [x[0] for x in st]
    #Got only genre names....
    
    st_genre

    
    def create_genre_list(st_genre):
        r=0
        while(True):
            r=r+1    
            # now take combination of genres....
            combination_genre = (itertools.permutations(st_genre, i + 1) for i in range(len(st_genre)))    
            all_permutations_gen = itertools.chain(*combination_genre)
            
            # Converted into list
            lst = list(all_permutations_gen)
            
            lst1 = []
            for i in lst:
                if len(i) == r :
                    lst1.append(i)
            #created list  pair of i combination..(combination of 2,3,...)
            #  got dictionary of genre and it's appearances.....
            anime_genre_dic = {}
            for i in lst1:
                count = 0
                str1 = ','.join(i)
                str1_sp = str1.split(",")
                for j in user_anime_genre:
                    if set(str1_sp).issubset(j.replace(" ","").split(",")):
                        count = count+1
                        
                anime_genre_dic[str1] = count
            
            #Sort the anime_genre_dic by value means by appearances....
            
            st = sorted(anime_genre_dic.items(), key=lambda anime_genre_dic: anime_genre_dic[1])
            
            #Reverse the dic means now we will get highest appearances...
            st = st[::-1]
            
            # Considering top 10 combination
            st1=[]
            k=0
            for i in st:
                p=0
                if k<10:
                    for j in st1:
                        if len(j[0]) == len(i[0]) and j[1] == i[1]:
                            p=1
                            break;
                    if p == 1:
                        continue;
                    else:
                        st1.append(i)
                        k=k+1
                        
            # converted ino list.
            st_genre = [x[0] for x in st1]
            
            ## here got top 10 genre list......
            st_genre = [i.split(",") for i in st_genre ]
            
            ##converting into single genre into list and makeing unique..
            st_genre = [item for sublist in st_genre for item in sublist]
            
            ## covert set into in list..
            st_genre  = list(set(st_genre))
            
            ## how many intration happen...
            if r==4:
                # retrning list of combination of 4 genre which appeared mostly..
                return st1
    
    #passing that genre list which contain most appeared and call function for doing next process..
    l = create_genre_list(st_genre)
    # in l got the final genre output
    l

    # taking animes which user not watched yet....
    user_not_watched_anime = anime_data2[~anime_data2['anime_id'].isin(user_anime_id)]
     
    
    
    len(user_not_watched_anime)
    
    len(user_anime_genre)
    
    # making index 0 to len(user_not_watched_anime)
    
    user_not_watched_anime = user_not_watched_anime[pd.notnull(user_not_watched_anime['genre'])]
    
    user_not_watched_anime.index = range(0,len(user_not_watched_anime))
    
    
    ##Now taking anime where we will check is genre in that anime.....
    anime_genre_dic = {}
    for i in range(0,len(user_not_watched_anime)):
        genre = user_not_watched_anime.loc[i,'genre']
        if set(l[0][0].replace(" ","").split(",")).issubset(genre.replace(" ","").split(",")):
            anime_genre_dic[user_not_watched_anime.loc[i,'name']] = user_not_watched_anime.loc[i,'rating']
    
    anime_genre_dic
    
    len(anime_genre_dic)
    
    st = sorted(anime_genre_dic.items(), key=lambda anime_genre_dic: anime_genre_dic[1])
            
    #Reverse the dic means now we will get highest appearances...
    st = st[::-1]
           
    st[0:40]    
    
    a1 = []
    for i in  range(0,len(st)): 
        is_there = 1
        if len(a1) == 0:
            a1.append(st[i][0])
        else:
            for j in range(0,len(a1)):
                if st[i][0].split(":")[0] == (a1[j].split(":")[0]):
                    is_there = 2
                    break
            if is_there == 1:
                a1.append(st[i][0])    
    return a1[0:10]


###########################################################

def calc_coverage_ap(user_id,anime_data,user_data):
    #user_id = 25
    anime_data2 = anime_data
    #geting user anime id.....
    user_anime_id = user_data.loc[user_data['user_id'] == user_id,'anime_id']
    #sorted by index
    user_anime_id.sort_index(inplace=True)
    #fetching user watched anime genre
    user_watched_anime = anime_data2.loc[anime_data2['anime_id'].isin(user_anime_id),'anime_id':'rating']
    user_anime_genre = anime_data2.loc[anime_data2['anime_id'].isin(user_anime_id),'genre']
    anime_genre_len =[]
    value = len(user_anime_id) - int(len(user_anime_id)*0.8)
    user_watched_anime = user_watched_anime[len(user_watched_anime)-value:len(user_watched_anime)]
    user_anime_genre = user_anime_genre[0:len(user_anime_genre)]
    
    anime_genre_1 =[]
    ## for 1st intration...
    ### Got genre in list of that user
    for i in user_anime_genre:
        lst = i.split(",")
        for i in lst:
            if i not in anime_genre_1:
                anime_genre_1.append(i)
                anime_genre_len.append(len(i))
        
    anime_genre_1 #---> in this list
    
    len(anime_genre_1)
    
    
    anime_genre_dic = {}
    for i in anime_genre_1:
        count = 0 
        for j in user_anime_genre:
            if i.strip() in j.replace(" ","").split(","):
                count = count+1
                
        anime_genre_dic[i.strip()] = count
    
    anime_genre_dic
    #  got dictionary of genre and it's appearances.....
    
    st = sorted(anime_genre_dic.items(), key=lambda anime_genre_dic: anime_genre_dic[1])
    # sorted that list base on appearance.. lowest to highest...
    
    st = st[::-1]
    
    ## reverse it..
    st = st[0:10]
    # top 10 ...
    
    st_genre = [x[0] for x in st]
    #Got only genre names....
    
    st_genre

    
    def create_genre_list(st_genre):
        r=0
        while(True):
            r=r+1    
            # now take combination of genres....
            combination_genre = (itertools.permutations(st_genre, i + 1) for i in range(len(st_genre)))    
            all_permutations_gen = itertools.chain(*combination_genre)
            
            # Converted into list
            lst = list(all_permutations_gen)
            
            lst1 = []
            for i in lst:
                if len(i) == r :
                    lst1.append(i)
            #created list  pair of i combination..(combination of 2,3,...)
            #  got dictionary of genre and it's appearances.....
            anime_genre_dic = {}
            for i in lst1:
                count = 0
                str1 = ','.join(i)
                str1_sp = str1.split(",")
                for j in user_anime_genre:
                    if set(str1_sp).issubset(j.replace(" ","").split(",")):
                        count = count+1
                        
                anime_genre_dic[str1] = count
            
            #Sort the anime_genre_dic by value means by appearances....
            
            st = sorted(anime_genre_dic.items(), key=lambda anime_genre_dic: anime_genre_dic[1])
            
            #Reverse the dic means now we will get highest appearances...
            st = st[::-1]
            
            # Considering top 10 combination
            st1=[]
            k=0
            for i in st:
                p=0
                if k<10:
                    for j in st1:
                        if len(j[0]) == len(i[0]) and j[1] == i[1]:
                            p=1
                            break;
                    if p == 1:
                        continue;
                    else:
                        st1.append(i)
                        k=k+1
                        
            # converted ino list.
            st_genre = [x[0] for x in st1]
            
            ## here got top 10 genre list......
            st_genre = [i.split(",") for i in st_genre ]
            
            ##converting into single genre into list and makeing unique..
            st_genre = [item for sublist in st_genre for item in sublist]
            
            ## covert set into in list..
            st_genre  = list(set(st_genre))
            
            ## how many intration happen...
            if r==4:
                # retrning list of combination of 4 genre which appeared mostly..
                return st1
    
    #passing that genre list which contain most appeared and call function for doing next process..
    l = create_genre_list(st_genre)
    # in l got the final genre output
    l
       
    ####################################
    
    anime_data2 = anime_data2[pd.notnull(anime_data2['genre'])]
    
    anime_data2.index = range(0,len(anime_data2))
    
    
    anime_genre_dic = {}
    for i in range(0,len(anime_data2)):
        genre = anime_data2.loc[i,'genre']
        if set(l[0][0].replace(" ","").split(",")).issubset(genre.replace(" ","").split(",")):
            anime_genre_dic[anime_data2.loc[i,'name']] = anime_data2.loc[i,'rating']
    
    anime_genre_dic
    
    len(anime_genre_dic)
    
    st = sorted(anime_genre_dic.items(), key=lambda anime_genre_dic: anime_genre_dic[1])
            
    #Reverse the dic means now we will get highest appearances...
    st = st[::-1]
           
    st[0:40]    
    
    a1 = []
    for i in  range(0,len(st)): 
        a1.append(st[i][0])
                
    a = a1
    fav_anime = merged_data.name[merged_data['user_id']==user_id].tolist()
    #fav_anime = user_watched_anime.name.tolist()
    cnt = 0
    for n in a:
        if n in fav_anime:
            cnt += 1
        else:
            continue
        
    return(cnt/len(fav_anime)*100)

######################################################
    
    
def calc_recall_ap(user_id,anime_data,user_data):
    anime_data2 = anime_data
    #geting user anime id.....
    user_anime_id = user_data.loc[user_data['user_id'] == user_id,'anime_id']
    #sorted by index
    user_anime_id.sort_index(inplace=True)
    #fetching user watched anime genre
    user_watched_anime = anime_data2.loc[anime_data2['anime_id'].isin(user_anime_id),'anime_id':'rating']
    user_anime_genre = anime_data2.loc[anime_data2['anime_id'].isin(user_anime_id),'genre']
    anime_genre_len =[]
    value = len(user_anime_id) - int(len(user_anime_id)*0.8)
    user_watched_anime = user_watched_anime[len(user_watched_anime)-value:len(user_watched_anime)]
    user_anime_genre = user_anime_genre[0:len(user_anime_genre)]

    anime_genre_1 =[]
    ## for 1st intration...
    ### Got genre in list of that user
    for i in user_anime_genre:
        lst = i.split(",")
        for i in lst:
            if i not in anime_genre_1:
                anime_genre_1.append(i)
                anime_genre_len.append(len(i))
        
    anime_genre_1 #---> in this list
    
    len(anime_genre_1)
    
    
    anime_genre_dic = {}
    for i in anime_genre_1:
        count = 0 
        for j in user_anime_genre:
            if i.strip() in j.replace(" ","").split(","):
                count = count+1
                
        anime_genre_dic[i.strip()] = count
    
    anime_genre_dic
    #  got dictionary of genre and it's appearances.....
    
    st = sorted(anime_genre_dic.items(), key=lambda anime_genre_dic: anime_genre_dic[1])
    # sorted that list base on appearance.. lowest to highest...
    
    st = st[::-1]
    
    ## reverse it..
    st = st[0:10]
    # top 10 ...
    
    st_genre = [x[0] for x in st]
    #Got only genre names....
    
    st_genre

    
    def create_genre_list(st_genre):
        r=0
        while(True):
            r=r+1    
            # now take combination of genres....
            combination_genre = (itertools.permutations(st_genre, i + 1) for i in range(len(st_genre)))    
            all_permutations_gen = itertools.chain(*combination_genre)
            
            # Converted into list
            lst = list(all_permutations_gen)
            
            lst1 = []
            for i in lst:
                if len(i) == r :
                    lst1.append(i)
            #created list  pair of i combination..(combination of 2,3,...)
            #  got dictionary of genre and it's appearances.....
            anime_genre_dic = {}
            for i in lst1:
                count = 0
                str1 = ','.join(i)
                str1_sp = str1.split(",")
                for j in user_anime_genre:
                    if set(str1_sp).issubset(j.replace(" ","").split(",")):
                        count = count+1
                        
                anime_genre_dic[str1] = count
            
            #Sort the anime_genre_dic by value means by appearances....
            
            st = sorted(anime_genre_dic.items(), key=lambda anime_genre_dic: anime_genre_dic[1])
            
            #Reverse the dic means now we will get highest appearances...
            st = st[::-1]
            
            # Considering top 10 combination
            st1=[]
            k=0
            for i in st:
                p=0
                if k<10:
                    for j in st1:
                        if len(j[0]) == len(i[0]) and j[1] == i[1]:
                            p=1
                            break;
                    if p == 1:
                        continue;
                    else:
                        st1.append(i)
                        k=k+1
                        
            # converted ino list.
            st_genre = [x[0] for x in st1]
            
            ## here got top 10 genre list......
            st_genre = [i.split(",") for i in st_genre ]
            
            ##converting into single genre into list and makeing unique..
            st_genre = [item for sublist in st_genre for item in sublist]
            
            ## covert set into in list..
            st_genre  = list(set(st_genre))
            
            ## how many intration happen...
            if r==4:
                # retrning list of combination of 4 genre which appeared mostly..
                return st1
    
    #passing that genre list which contain most appeared and call function for doing next process..
    l = create_genre_list(st_genre)
    # in l got the final genre output
    l
       
    ####################################
    
    anime_data2 = anime_data2[pd.notnull(anime_data2['genre'])]
    
    anime_data2.index = range(0,len(anime_data2))
    
    
    anime_genre_dic = {}
    for i in range(0,len(anime_data2)):
        genre = anime_data2.loc[i,'genre']
        if set(l[0][0].replace(" ","").split(",")).issubset(genre.replace(" ","").split(",")):
            anime_genre_dic[anime_data2.loc[i,'name']] = anime_data2.loc[i,'rating']
    
    anime_genre_dic
    
    len(anime_genre_dic)
    
    st = sorted(anime_genre_dic.items(), key=lambda anime_genre_dic: anime_genre_dic[1])
            
    #Reverse the dic means now we will get highest appearances...
    st = st[::-1]
           
    st[0:40]    
    
    a1 = []
    for i in  range(0,len(st)): 
        a1.append(st[i][0])
                
    a = a1
    #fav_anime = merged_data.name[merged_data['user_id']==user_id].tolist()
    fav_anime = anime_data2.loc[anime_data2['anime_id'].isin(user_anime_id),'anime_id':'rating']
    fav_anime = fav_anime.name.tolist()
    cnt = 0
    for n in a:
        if n in fav_anime:
            cnt += 1
        else:
            continue
        
    return(cnt/len(fav_anime)*100)

print(calc_coverage_ap(25,anime_data,user_data))
print(calc_recall_ap(7,anime_data,user_data))
    
#############################       Sangeeth         #############################



def get_reccomendation_by_content(anime_name,anime_data):
        anime_data1 = anime_data
    #Imputing missing values in type column-25 Na's
    #imputing empty values in 'type' with Mode['TV']
        anime_data1['type']=anime_data1['type'].replace("",np.max(anime_data1['type']))
        anime_data1['type'].unique()
        
        #dropping the rows that has na's in anime dataset
        anime_data1['genre']=anime_data1['genre'].replace("",np.NaN)
        anime_data1['episodes']=anime_data1['episodes'].replace("Unknown",np.NaN)
        anime_data1=anime_data1.dropna(how='any',axis=0)
        ##replacing empty ratings with medians
        anime_data1['rating'].dtype.name
        anime_data1['rating'] = anime_data1['rating'].replace(" ",0.0)
        anime_data1['rating']=anime_data1['rating'].apply(pd.to_numeric,downcast='integer')
        anime_data1['rating'] = anime_data1['rating'].fillna(0.0)
        anime_data1.isna().sum()
        #converting members into numeric
        anime_data1['members']=pd.to_numeric(anime_data1['members'],errors='coerce')
        anime_data1.dtypes
        ##Concatenating all variables(One-hot-encoding)
        anime_features = pd.concat([anime_data1["genre"].str.get_dummies(sep=","),pd.get_dummies(anime_data1[["type"]]),anime_data1[["rating"]],anime_data1[["members"]],anime_data1["episodes"]],axis=1)
        anime_features.head()
        anime_features.columns
        #####calculating the cosine similarity between the features
        similarity_cosine=cosine_similarity(anime_features.values,anime_features.values)
        #Now we must create an indexing for each anime name, this will be used when we will #query a recommendation.
        anime_index=pd.Series(anime_data1.index,index=anime_data1.name).drop_duplicates()
        anime_index.head()
        
        def get_recommendation(anime_name):
           idx=anime_index[anime_name]
           similarity_scores=list(enumerate(similarity_cosine[idx]))
           similarity_scores = sorted(similarity_scores, key=lambda x: x[1], reverse=True)
           similarity_scores = similarity_scores[0:12]
           indices=[i[0] for i in similarity_scores]
           result=anime_data[['name']].iloc[indices]
           result1=result.loc[:,'name']
           return result1.tolist()
           
        #
        #get_recommendation('Naruto')
        #get_recommendation('Nogizaka Haruka no Himitsu',anime_index,cosine_sim)
        
        
        return get_recommendation(anime_name)
    
def recommendation_by_user_and_item(user_id,anime_name,anime_data,rating_data):
    user_id = 10
    rating_data=user_data
    anime_name="Angel Beats!"
    rating_data.shape
        
    rating_data.loc[rating_data.rating == -1, 'rating'] =0
    rating_data['rating']=rating_data['rating'].replace(0,np.NaN)
    rating_data.head()
    anime_index=pd.Series(anime_data.index,index=anime_data.name)
    anime_index.head()
    merged_data=anime_data.merge(rating_data,how='inner',on='anime_id')
    merged_data=merged_data[['user_id','name','rating_y']]
    print(merged_data.head())
    pivot_data=pd.pivot_table(merged_data,index='name',columns='user_id',values='rating_y')
    pivot_data.shape
    #Drop all users that never rate an anime
    pivot_data.dropna(axis=1,how='all',inplace=True)
    pivot_data.shape
    #Normalizing
    normalize_pivot=pivot_data.apply(lambda x:x-np.mean(x),axis=1)
    normalize_pivot.head()
    normalize_pivot.fillna(0,inplace=True)
    ##Calculating similar items
    item_cosine_sim=pd.DataFrame(cosine_similarity(normalize_pivot,normalize_pivot),index=normalize_pivot.index,columns=normalize_pivot.index)
    item_cosine_sim.head()
    ##Similar Items
    def get_similar_anime(anime_name):
       if anime_name not in normalize_pivot.index:
           return None, None
       else:
           sim_animes = item_cosine_sim.sort_values(by=anime_name, ascending=False).index[1:]
           sim_score = item_cosine_sim.sort_values(by=anime_name, ascending=False).loc[:, anime_name].tolist()[1:]
           return sim_animes, sim_score

    animes, score = get_similar_anime(anime_name)
    print(animes)
    print(score)
    for x,y in zip(animes[:10], score[:10]):
       print("{} with similarity of {}".format(x, y))
    # predict the rating of anime x by user y
    def predict_rating(user_id, anime_name, max_neighbor=10):
       animes, scores = get_similar_anime(anime_name)
       anime_array = np.array([x for x in animes])
       sim_array = np.array([x for x in scores])
    
       # select only the anime that has already rated by user x
       filtering = normalize_pivot[user_id].loc[anime_array] != 0
    
       # calculate the predicted score
       s = np.dot(sim_array[filtering][:max_neighbor], pivot_data[user_id].loc[anime_array[filtering][:max_neighbor]]) \
           / np.sum(sim_array[filtering][:max_neighbor])
    
       return s
    predict_rating(user_id,anime_name)
    
    #recommend top n_anime for user x based on item collaborative filtering algorithm
    def get_recommendation_for_user(user_id, n_anime=10):
       predicted_rating = np.array([])
    
       for _anime in normalize_pivot.index:
           predicted_rating = np.append(predicted_rating, predict_rating(user_id, _anime))
    
       # don't recommend something that user has already rated
       dummy = pd.DataFrame({'predicted': predicted_rating, 'name': normalize_pivot.index})
       dummy = dummy.sort_values(by='predicted', ascending=False)
    
       # recommend n_anime anime
       return anime_data.loc[anime_index.loc[dummy.name[:n_anime]]]
       def coverage(uid):
        a = get_recommendation_for_user(uid,100)
        a = a['name'][0:100].tolist()
        
        uid_data = merged_data[merged_data['user_id']==uid]
        fav_anime = uid_data.name[merged_data['rating_y'] >= merged_data['mean_rating']].tolist()
        
        cnt = 0
        for n in a:
            if n in fav_anime:
                cnt += 1
            else:
                continue
        return("The coverage for user {0} is {1}%".format(uid, cnt/len(fav_anime)*100))
        coverage(user_id)
        
# =============================================================================
#         def recall(uid):
#             a = get_recommendation_for_user(uid, 100)
#             a = a['name'].tolist()
#             watched_anime = joined.name[joined['user_id'] == uid].tolist()
#             cnt = 0
#             for n in a:
#                 if n in watched_anime:
#                     cnt += 1
#                 else:
#                     continue
#             return ("The recall for user {0} is {1}%".format(uid,cnt/len(watched_anime) * 100 ))
#               
# =============================================================================
    return get_recommendation_for_user(user_id)
    
    
   
    #recall(7)#9.523809523809524%
    #recall(25)#0.0%
    #recall(250)#0.0%
    #recall(5010)#9.090909090909092%



#############################       Harish         #############################
    

    
def get_recommendation_clust(uid, n_anime=10):
    if user_anime_df.loc[uid,'cluster'][0] == 0:
        rec_anime = (c0.sort_values(ascending=False)[0:n_anime])
    else:
        if user_anime_df.loc[uid,'cluster'][0] == 1:
            rec_anime = (c1.sort_values(ascending=False)[0:n_anime])
        else:
            if user_anime_df.loc[uid,'cluster'][0] == 2:
                rec_anime = (c2.sort_values(ascending=False)[0:n_anime])
            else:
                rec_anime = (c3.sort_values(ascending=False)[0:n_anime])
                
    df1 = pd.DataFrame()
    for i in range(0,len(rec_anime)):
        d1 = anime[anime.name == rec_anime.index[i][1]]
        df1 = df1.append(d1, ignore_index=True)
        
    return df1.loc[:,df1.columns != 'anime_id']
    
def calc_coverage(uid):
    a = get_recommendation_clust(uid,1000)
    a = a['name'][0:100].tolist()
    fav_anime = merged_data.name[merged_data['user_id']==uid].tolist()
    cnt = 0
    for n in a:
        if n in fav_anime:
            cnt += 1
        else:
            continue
    return(cnt/len(fav_anime)*100)


#############################       Akshay         #############################


def get_recommendation_by_anime_name(anime_name,anime_data,rating_data):
    # Data Preprocessing
    rating_data = pd.merge(rating_data, anime_data.drop('rating', axis=1), on='anime_id')
    rating_data.head()
    
    rating_data.groupby('name')['rating'].count().sort_values(ascending=False).head(10)
    
    ratings = pd.DataFrame(rating_data.groupby('name')['rating'].mean())
    ratings['num of ratings'] = pd.DataFrame(rating_data.groupby('name')['rating'].count())
    
    genre_dict = pd.DataFrame(data=anime_data[['name', 'genre']])
    genre_dict.set_index('name', inplace=True)
    
    ratings.head()

    def check_genre(genre_list, string):
        if any(x in string for x in genre_list):
            return True
        else:
            return False


    def get_recommendation(name,num=10):

        # generated list of animes with the same genre with target
        anime_genre = genre_dict.loc[name].values[0].split(', ')
        cols = anime_data[anime_data['genre'].apply(
            lambda x: check_genre(anime_genre, str(x)))]['name'].tolist()
    
        # create matrix based on generated list
        anime_mat = rating_data[rating_data['name'].isin(cols)].pivot_table(index='user_id', columns='name', values='rating')
    
        # create correlation table
        anime_user_rating = anime_mat[name]
        similiar_anime = anime_mat.corrwith(anime_user_rating)
        corre_anime = pd.DataFrame(similiar_anime, columns=['correlation'])
        corre_anime = corre_anime.join(ratings['num of ratings'])
        corre_anime.dropna(inplace=True)
        corre_anime = corre_anime[corre_anime['num of ratings'] > 7000].sort_values('correlation', ascending=False)
    
        return corre_anime[0:num]
    
    return get_recommendation(anime_name)



#############################       Flask Code         #############################


@app.route('/') ## index page.
def index():
    return render_template('index.html',main_page_background=main_page_background,log_error_mesage = " ")

@app.route('/', methods=['POST']) ## index page with input value..
def my_form_post():
    if request.method == 'POST':
        text = request.form.get('logout')
        if text == 'logout':
            return redirect(url_for('index'))
        else:
            text = request.form['text'] #User_Id --> from login or index page.
            user_id = text
            if text.lower() == 'admin':
                return render_template('home.html',text=user_id,main_page_background=main_page_background)
            else:
                anime_list1 = get_recommendation_clust(int(user_id.strip()))
                anime_list1=anime_list1.loc[:,'name']
                genre_recommenadation_list =  recommendation_by_user_common_genre(int(text.strip()),anime_data,user_data)
                anime_poster_number_rec = np.random.randint(1,25,10)
                #print(genre_recommenadation_list)
                anime_poster_number_rec1 = np.random.randint(1,25,10)
    
                return render_template('home_user.html',anime_list1_len = len(anime_list1)-2,anime_list1=anime_list1,anime_poster_number_rec1 = anime_poster_number_rec1,anime_poster_number_rec = anime_poster_number_rec,genre_recommenadation_list_len = len(genre_recommenadation_list)-2,genre_recommenadation_list=genre_recommenadation_list,text=int(user_id.strip()),anime_name = json.dumps(anime_name.tolist()),main_page_background=main_page_background)
                

@app.route('/home_user', methods=['POST']) ## home user...
def my_home_user_post_search():
    user_id = request.form.get('user_id')
    anime_list1 = get_recommendation_clust(int(user_id.strip()))
    anime_list1=anime_list1.loc[:,'name']
    genre_recommenadation_list =  recommendation_by_user_common_genre(int(user_id.strip()),anime_data,user_data)
    anime_poster_number_rec = np.random.randint(1,25,10)
    anime_poster_number_rec1 = np.random.randint(1,25,10)
    return render_template('home_user.html',anime_list1_len = len(anime_list1)-2,anime_list1=anime_list1,anime_poster_number_rec1 = anime_poster_number_rec1,anime_poster_number_rec = anime_poster_number_rec,genre_recommenadation_list_len = len(genre_recommenadation_list)-2,genre_recommenadation_list=genre_recommenadation_list,text=int(user_id.strip()),anime_name = json.dumps(anime_name.tolist()),main_page_background=main_page_background)

    
@app.route('/anime_details', methods=['POST']) ## search...
def my_form_post_search():
    selected_anime_name = request.form.get('search')
    user_id = request.form.get('user_id')
    anime_poster_number = np.random.randint(1,25,1)
    selected_anime_details = anime_data[anime_data['name'] == selected_anime_name]
    anime_list = get_reccomendation_by_content(selected_anime_name,anime_data)
    anime_poster_number_rec = np.random.randint(1,25,10)
    print(anime_list[1:11])
    return render_template('anime_details.html',len_anime = len(anime_list[1:11])-2,anime_poster_number_rec = anime_poster_number_rec,anime_list = anime_list[1:11],selected_anime_details = selected_anime_details,anime_poster_number = anime_poster_number[0],selected_anime_name = selected_anime_name,text=user_id,anime_name = json.dumps(anime_name.tolist()))


## this to cheack is name is main if it is then run application
if __name__ == '__main__':
    app.run(debug=True, port=5001)











